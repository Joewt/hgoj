module.exports = {
  markdown: '>'.repeat(5000),
  html: '<blockquote>'.repeat(5000) + '</blockquote>'.repeat(5000)
};
